<template>
  <h2>{{ titulo }}</h2>
</template>

<script>
export default {
  data() {
    return {
      titulo: "Lista de Tareas"
    };
  }
};
</script>
